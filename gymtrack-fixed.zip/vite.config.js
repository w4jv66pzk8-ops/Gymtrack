import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base './' makes asset URLs relative, so the build works when GitHub Pages
// serves it from https://<user>.github.io/Gymtrack/ (a sub-path, not the domain root).
export default defineConfig({
  base: './',
  plugins: [react()],
})
