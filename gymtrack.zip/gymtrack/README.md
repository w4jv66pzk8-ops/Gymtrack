# GYMTRACK – Gym Management App

Fees register, membership renewals and missing-member tracking for a small gym.
React + Vite + Tailwind CSS, with Supabase (Postgres + Auth) as the database.

## 1. Create the database (5 minutes)

1. Create a free project at https://supabase.com.
2. Open **SQL Editor → New query**, paste everything from `supabase/schema.sql`, click **Run**.
   This creates all tables, security rules, and **16 sample members** with payments and attendance.
3. (Recommended for easy setup) **Authentication → Providers → Email → turn off "Confirm email"**,
   so the admin account works right after sign-up.

## 2. Run the app

```bash
npm install
cp .env.example .env     # then paste your Project URL and anon key (Project Settings → API)
npm run dev
```

Open the printed URL, click **"First time? Create the admin account"**, and sign up.

> After creating your admin account, go to **Authentication → Providers → Email** and turn off
> **"Allow new users to sign up"** so nobody else can create an account on your gym's data.

## 3. Remove the sample data

In the Supabase SQL Editor run: `truncate members cascade;`
Then add your real members from the app. (Plans can be edited in Settings.)

## Deploying

`npm run build` creates a `dist/` folder. Upload it to Netlify, Vercel or Cloudflare Pages and set the
two environment variables `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
The app uses hash routing, so no extra redirect rules are needed.

## How it works

| Area | Behaviour |
|---|---|
| Expiry | `expiry_date = cycle start + plan months`. Renewing before expiry continues from the old expiry; after expiry it starts today. |
| Payment status | Per current cycle: **Paid** (paid ≥ fee), **Partially paid**, **Unpaid**. Old dues carry forward on renewal. |
| Missing members | Days since last attendance (or joining date if never attended). Chips for 3 / 7 / 15 / 30 days. Marking someone present re-activates them. |
| WhatsApp | Opens `wa.me` with a message built from the templates in Settings. Default country code is 91 (India). |
| Receipts | Generated for every payment. Print / Save as PDF or share on WhatsApp. |
| Backup | Settings → Download backup (JSON). Restore from the same screen. |

## Project structure

```
supabase/schema.sql        tables, RLS policies, sample data
src/lib/                   supabase client, date/money/CSV/WhatsApp helpers
src/context/               AuthContext, DataContext (all CRUD actions)
src/components/            UI kit, forms, receipt, layout, chart
src/pages/                 Dashboard, Members, MemberProfile, Fees, Renewals,
                           Missing, Attendance, Settings, Login
```
