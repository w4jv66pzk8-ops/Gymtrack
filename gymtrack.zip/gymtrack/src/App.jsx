import { Navigate, Route, Routes } from 'react-router-dom'
import { isConfigured } from './lib/supabase'
import { AuthProvider, useAuth } from './context/AuthContext'
import { DataProvider } from './context/DataContext'
import { ToastProvider } from './components/Toast'
import { Spinner } from './components/UI'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Members from './pages/Members'
import MemberProfile from './pages/MemberProfile'
import Fees from './pages/Fees'
import Renewals from './pages/Renewals'
import Missing from './pages/Missing'
import Attendance from './pages/Attendance'
import SettingsPage from './pages/Settings'

function SetupNeeded() {
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="w-full max-w-xl rounded-2xl border border-neutral-800 bg-neutral-900 p-6">
        <h1 className="text-xl font-bold">
          GYM<span className="text-orange-500">TRACK</span> – one-time setup
        </h1>
        <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm text-neutral-300">
          <li>Create a free project at supabase.com.</li>
          <li>
            Open <b>SQL Editor</b>, paste the contents of <code className="text-orange-400">supabase/schema.sql</code> and run it.
          </li>
          <li>
            Copy <code className="text-orange-400">.env.example</code> to <code className="text-orange-400">.env</code> and paste your
            Project URL and anon key (Project Settings → API).
          </li>
          <li>Restart <code className="text-orange-400">npm run dev</code>.</li>
        </ol>
      </div>
    </div>
  )
}

function Protected() {
  const { session, loading } = useAuth()
  if (loading)
    return (
      <div className="grid min-h-screen place-items-center">
        <Spinner />
      </div>
    )
  if (!session) return <Login />
  return (
    <DataProvider>
      <Layout />
    </DataProvider>
  )
}

export default function App() {
  if (!isConfigured) return <SetupNeeded />
  return (
    <ToastProvider>
      <AuthProvider>
        <Routes>
          <Route element={<Protected />}>
            <Route index element={<Dashboard />} />
            <Route path="members" element={<Members />} />
            <Route path="members/:id" element={<MemberProfile />} />
            <Route path="fees" element={<Fees />} />
            <Route path="renewals" element={<Renewals />} />
            <Route path="missing" element={<Missing />} />
            <Route path="attendance" element={<Attendance />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </AuthProvider>
    </ToastProvider>
  )
}
