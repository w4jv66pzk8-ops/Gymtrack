import { useState } from 'react'
import { useData } from '../context/DataContext'
import { useToast } from './Toast'
import { today } from '../lib/utils'
import { Btn, Field, METHODS, Modal, PayBadge, inputCls } from './UI'

// Record a payment against a member's pending dues.
export default function PaymentModal({ member, onClose, onDone }) {
  const { addPayment, money } = useData()
  const toast = useToast()
  const [f, setF] = useState({ amount: member.due || '', method: 'cash', paid_on: today(), note: '' })
  const [err, setErr] = useState({})
  const [busy, setBusy] = useState(false)
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }))

  const submit = async (e) => {
    e.preventDefault()
    const v = {}
    const amt = Number(f.amount)
    if (member.due <= 0) v.amount = 'No pending dues. Use Renew to take an advance payment.'
    else if (!(amt > 0)) v.amount = 'Enter an amount greater than 0'
    else if (amt > member.due) v.amount = `Cannot be more than the pending ${money(member.due)}`
    if (!f.paid_on || f.paid_on > today()) v.paid_on = 'Choose today or an earlier date'
    setErr(v)
    if (Object.keys(v).length) return

    setBusy(true)
    try {
      const payment = await addPayment(member, f)
      toast.success('Payment recorded')
      onDone?.(payment)
      onClose()
    } catch (x) {
      toast.error(x.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal title="Collect payment" onClose={onClose}>
      <div className="mb-4 rounded-xl bg-neutral-900 p-3 text-sm">
        <div className="flex items-center justify-between">
          <b>{member.name}</b>
          <PayBadge status={member.pay} />
        </div>
        <div className="mt-1 text-neutral-400">
          Fee {money(member.cycle_fee)} · Paid {money(member.cycle_paid)} ·{' '}
          <span className="font-semibold text-orange-400">Due {money(member.due)}</span>
        </div>
      </div>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Amount received" error={err.amount}>
            <input type="number" min="0" className={inputCls} value={f.amount} onChange={(e) => set('amount', e.target.value)} autoFocus />
          </Field>
          <Field label="Date" error={err.paid_on}>
            <input type="date" max={today()} className={inputCls} value={f.paid_on} onChange={(e) => set('paid_on', e.target.value)} />
          </Field>
        </div>
        <Field label="Payment method">
          <select className={inputCls} value={f.method} onChange={(e) => set('method', e.target.value)}>
            {METHODS.map((m) => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Note (optional)">
          <input className={inputCls} value={f.note} onChange={(e) => set('note', e.target.value)} placeholder="e.g. Part payment" />
        </Field>
        <div className="flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save payment'}</Btn>
        </div>
      </form>
    </Modal>
  )
}
