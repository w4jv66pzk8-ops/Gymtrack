import { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation } from 'react-router-dom'
import {
  CalendarCheck,
  Dumbbell,
  IndianRupee,
  LayoutDashboard,
  LogOut,
  MoreHorizontal,
  RefreshCw,
  Settings,
  UserX,
  Users,
  X,
} from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useData } from '../context/DataContext'
import { Btn, Spinner } from './UI'

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/members', label: 'Members', icon: Users },
  { to: '/fees', label: 'Fees', icon: IndianRupee },
  { to: '/renewals', label: 'Renewals', icon: RefreshCw },
  { to: '/missing', label: 'Missing', icon: UserX },
  { to: '/attendance', label: 'Attendance', icon: CalendarCheck },
  { to: '/settings', label: 'Settings', icon: Settings },
]

const linkCls = ({ isActive }) =>
  `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
    isActive ? 'bg-orange-500 text-white' : 'text-neutral-400 hover:bg-neutral-900 hover:text-white'
  }`

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="grid h-9 w-9 place-items-center rounded-xl bg-orange-500">
        <Dumbbell size={20} className="text-white" />
      </div>
      <span className="text-xl font-extrabold tracking-tight">
        GYM<span className="text-orange-500">TRACK</span>
      </span>
    </div>
  )
}

export default function Layout() {
  const { signOut } = useAuth()
  const { loading, error, reload, settings } = useData()
  const [drawer, setDrawer] = useState(false)
  const loc = useLocation()

  useEffect(() => setDrawer(false), [loc.pathname])

  const Sidebar = (
    <div className="flex h-full flex-col p-4">
      <Logo />
      <div className="mt-1 truncate pl-11 text-xs text-neutral-500">{settings.gym_name}</div>
      <nav className="mt-6 flex-1 space-y-1">
        {NAV.map((n) => (
          <NavLink key={n.to} to={n.to} end={n.end} className={linkCls}>
            <n.icon size={18} />
            {n.label}
          </NavLink>
        ))}
      </nav>
      <button
        type="button"
        onClick={signOut}
        className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-neutral-400 hover:bg-neutral-900 hover:text-white"
      >
        <LogOut size={18} /> Sign out
      </button>
    </div>
  )

  return (
    <div className="min-h-screen">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-neutral-900 bg-neutral-950 lg:block">
        {Sidebar}
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-neutral-900 bg-neutral-950/95 px-4 py-3 backdrop-blur lg:hidden">
        <Logo />
        <div className="max-w-[40%] truncate text-xs text-neutral-500">{settings.gym_name}</div>
      </header>

      {/* Mobile drawer */}
      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70" onClick={() => setDrawer(false)} />
          <div className="absolute inset-y-0 right-0 w-72 border-l border-neutral-800 bg-neutral-950">
            <button
              type="button"
              className="absolute right-3 top-3 text-neutral-400"
              onClick={() => setDrawer(false)}
            >
              <X size={20} />
            </button>
            {Sidebar}
          </div>
        </div>
      )}

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-neutral-900 bg-neutral-950/95 backdrop-blur lg:hidden">
        {NAV.slice(0, 4).map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.end}
            className={({ isActive }) =>
              `flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium ${
                isActive ? 'text-orange-500' : 'text-neutral-500'
              }`
            }
          >
            <n.icon size={20} />
            {n.label}
          </NavLink>
        ))}
        <button
          type="button"
          onClick={() => setDrawer(true)}
          className="flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium text-neutral-500"
        >
          <MoreHorizontal size={20} />
          More
        </button>
      </nav>

      <main className="pb-24 lg:pb-8 lg:pl-64">
        <div className="mx-auto max-w-6xl p-4 sm:p-6">
          {loading ? (
            <div className="grid place-items-center py-32">
              <Spinner />
            </div>
          ) : error ? (
            <div className="mx-auto max-w-lg rounded-2xl border border-red-900 bg-red-950/40 p-6">
              <h2 className="text-lg font-semibold text-red-300">Could not load your data</h2>
              <p className="mt-2 text-sm text-red-200/80">{error}</p>
              <p className="mt-2 text-sm text-neutral-400">
                Make sure you ran <code className="text-orange-400">supabase/schema.sql</code> in the Supabase SQL Editor.
              </p>
              <Btn className="mt-4" onClick={reload}>Try again</Btn>
            </div>
          ) : (
            <Outlet />
          )}
        </div>
      </main>
    </div>
  )
}
