import { Printer } from 'lucide-react'
import { useData } from '../context/DataContext'
import { fmtDate, receiptNo, waLink } from '../lib/utils'
import { Btn, Modal, WaBtn } from './UI'

export default function Receipt({ payment, onClose }) {
  const { memberById, settings, money } = useData()
  const m = memberById[payment.member_id]
  const no = receiptNo(payment.receipt_no)

  const text = [
    `*${settings.gym_name} - Payment Receipt*`,
    `Receipt: ${no}`,
    `Member: ${m?.name || ''}`,
    `Amount received: ${money(payment.amount)}`,
    `Date: ${fmtDate(payment.paid_on)}`,
    `Mode: ${payment.method.toUpperCase()}`,
    `Balance due: ${money(m?.due || 0)}`,
    `Thank you! 💪`,
  ].join('\n')

  return (
    <Modal title="Payment receipt" onClose={onClose}>
      <div id="receipt-print" className="rounded-xl bg-white p-6 text-neutral-900">
        <div className="border-b border-dashed border-neutral-300 pb-3 text-center">
          <div className="text-xl font-extrabold tracking-tight">{settings.gym_name}</div>
          {settings.address && <div className="text-xs text-neutral-500">{settings.address}</div>}
          {settings.phone && <div className="text-xs text-neutral-500">Phone: {settings.phone}</div>}
        </div>
        <div className="mt-3 flex justify-between text-sm">
          <span className="font-semibold">Receipt {no}</span>
          <span>{fmtDate(payment.paid_on)}</span>
        </div>
        <dl className="mt-3 space-y-1.5 text-sm">
          <Row k="Member" v={m?.name || '—'} />
          <Row k="Phone" v={m?.phone || '—'} />
          <Row k="Plan" v={m?.plan_name || '—'} />
          <Row k="Valid till" v={m ? fmtDate(m.expiry_date) : '—'} />
          <Row k="Payment mode" v={payment.method.toUpperCase()} />
          {payment.note && <Row k="Note" v={payment.note} />}
        </dl>
        <div className="mt-4 flex items-center justify-between rounded-lg bg-orange-50 px-4 py-3">
          <span className="text-sm font-medium">Amount received</span>
          <span className="text-2xl font-extrabold text-orange-600">{money(payment.amount)}</span>
        </div>
        <div className="mt-2 text-right text-xs text-neutral-500">
          Balance due: {money(m?.due || 0)}
        </div>
        <div className="mt-4 border-t border-dashed border-neutral-300 pt-3 text-center text-xs text-neutral-500">
          Thank you for training with us!
        </div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Btn onClick={() => window.print()}>
          <Printer size={16} /> Print / Save PDF
        </Btn>
        {m && <WaBtn size="md" href={waLink(m.phone, text, settings.country_code)} label="Send on WhatsApp" />}
        <Btn variant="ghost" onClick={onClose}>
          Close
        </Btn>
      </div>
    </Modal>
  )
}

const Row = ({ k, v }) => (
  <div className="flex justify-between gap-4">
    <dt className="text-neutral-500">{k}</dt>
    <dd className="text-right font-medium">{v}</dd>
  </div>
)
