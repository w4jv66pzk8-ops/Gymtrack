import { useState } from 'react'
import { useData } from '../context/DataContext'
import { useToast } from './Toast'
import { addMonths, fmtDate, today } from '../lib/utils'
import { Btn, Field, METHODS, Modal, inputCls } from './UI'

// Renew a membership (same plan or a different one).
export default function RenewModal({ member, onClose, onDone }) {
  const { plans, renewMember, money } = useData()
  const toast = useToast()
  const first = plans.find((p) => p.id === member.plan_id) || plans[0]
  const [f, setF] = useState({
    plan_id: first?.id || '',
    fee_amount: first?.price ?? '',
    paid_amount: '',
    method: 'cash',
  })
  const [err, setErr] = useState({})
  const [busy, setBusy] = useState(false)
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }))

  const plan = plans.find((p) => p.id === f.plan_id)
  const expired = member.daysLeft < 0
  const start = expired ? today() : member.expiry_date
  const newExpiry = plan ? addMonths(start, plan.months) : null
  const carry = member.due
  const total = Number(f.fee_amount || 0) + carry

  const onPlan = (id) => {
    const p = plans.find((x) => x.id === id)
    setF((s) => ({ ...s, plan_id: id, fee_amount: p ? p.price : '' }))
  }

  const submit = async (e) => {
    e.preventDefault()
    const v = {}
    const fee = Number(f.fee_amount)
    const paid = Number(f.paid_amount || 0)
    if (!f.plan_id) v.plan_id = 'Choose a plan'
    if (f.fee_amount === '' || isNaN(fee) || fee < 0) v.fee_amount = 'Enter the renewal fee'
    if (isNaN(paid) || paid < 0) v.paid_amount = 'Enter 0 or a positive amount'
    else if (!v.fee_amount && paid > total) v.paid_amount = `Cannot be more than ${money(total)}`
    setErr(v)
    if (Object.keys(v).length) return

    setBusy(true)
    try {
      const payment = await renewMember(member, f)
      toast.success(`${member.name} renewed till ${fmtDate(newExpiry)}`)
      onDone?.(payment)
      onClose()
    } catch (x) {
      toast.error(x.message)
    } finally {
      setBusy(false)
    }
  }

  if (plans.length === 0) {
    return (
      <Modal title="Renew membership" onClose={onClose}>
        <p className="text-sm text-neutral-300">Add a membership plan in Settings first.</p>
      </Modal>
    )
  }

  return (
    <Modal title={`Renew – ${member.name}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <div className="rounded-xl bg-neutral-900 p-3 text-sm text-neutral-300">
          Current plan <b>{member.plan_name}</b>, {expired ? 'expired on' : 'expires on'}{' '}
          <b className={expired ? 'text-red-400' : 'text-orange-400'}>{fmtDate(member.expiry_date)}</b>.
          {expired ? ' The new period starts today.' : ' The new period starts when the current one ends.'}
        </div>
        <Field label="Plan" error={err.plan_id}>
          <select className={inputCls} value={f.plan_id} onChange={(e) => onPlan(e.target.value)}>
            {plans.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} – {p.months} month{p.months > 1 ? 's' : ''} – {money(p.price)}
              </option>
            ))}
          </select>
        </Field>
        {newExpiry && (
          <p className="-mt-2 text-xs text-neutral-400">
            New expiry date: <b className="text-orange-400">{fmtDate(newExpiry)}</b>
          </p>
        )}
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Renewal fee" error={err.fee_amount}>
            <input type="number" min="0" className={inputCls} value={f.fee_amount} onChange={(e) => set('fee_amount', e.target.value)} />
          </Field>
          <Field label="Amount paid now" error={err.paid_amount}>
            <input type="number" min="0" className={inputCls} value={f.paid_amount} onChange={(e) => set('paid_amount', e.target.value)} placeholder="0" />
          </Field>
        </div>
        {carry > 0 && (
          <p className="text-xs text-amber-400">
            Previous pending dues of {money(carry)} are carried forward. Total payable: {money(total)}.
          </p>
        )}
        <Field label="Payment method">
          <select className={inputCls} value={f.method} onChange={(e) => set('method', e.target.value)}>
            {METHODS.map((m) => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
        </Field>
        <div className="flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn type="submit" disabled={busy}>{busy ? 'Renewing…' : 'Confirm renewal'}</Btn>
        </div>
      </form>
    </Modal>
  )
}
