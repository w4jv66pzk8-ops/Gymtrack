import { useState } from 'react'
import { useData } from '../context/DataContext'
import { useToast } from './Toast'
import { addMonths, cleanPhone, fmtDate, today, validPhone } from '../lib/utils'
import { Btn, Field, METHODS, Modal, inputCls } from './UI'

// Used for both adding a new member and editing an existing one.
export default function MemberForm({ member, onClose, onSaved }) {
  const { plans, addMember, updateMember, money } = useData()
  const toast = useToast()
  const edit = Boolean(member)

  const [f, setF] = useState(() =>
    edit
      ? { name: member.name, phone: member.phone, joining_date: member.joining_date, notes: member.notes || '' }
      : {
          name: '',
          phone: '',
          joining_date: today(),
          plan_id: plans[0]?.id || '',
          fee_amount: plans[0]?.price ?? '',
          paid_amount: '',
          method: 'cash',
          notes: '',
        }
  )
  const [err, setErr] = useState({})
  const [busy, setBusy] = useState(false)
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }))

  const onPlan = (id) => {
    const p = plans.find((x) => x.id === id)
    setF((s) => ({ ...s, plan_id: id, fee_amount: p ? p.price : '' }))
  }

  const plan = plans.find((p) => p.id === f.plan_id)

  const submit = async (e) => {
    e.preventDefault()
    const v = {}
    if (f.name.trim().length < 2) v.name = 'Enter the member name'
    if (!validPhone(f.phone)) v.phone = 'Enter a valid 10-digit mobile number'
    if (!f.joining_date) v.joining_date = 'Choose the joining date'
    else if (f.joining_date > today()) v.joining_date = 'Joining date cannot be in the future'
    if (!edit) {
      if (!f.plan_id) v.plan_id = 'Choose a plan'
      const fee = Number(f.fee_amount)
      const paid = Number(f.paid_amount || 0)
      if (f.fee_amount === '' || isNaN(fee) || fee < 0) v.fee_amount = 'Enter the fee amount'
      if (isNaN(paid) || paid < 0) v.paid_amount = 'Enter 0 or a positive amount'
      else if (!v.fee_amount && paid > fee) v.paid_amount = 'Paid amount cannot be more than the fee'
    }
    setErr(v)
    if (Object.keys(v).length) return

    setBusy(true)
    try {
      if (edit) {
        await updateMember(member.id, {
          name: f.name.trim(),
          phone: cleanPhone(f.phone),
          joining_date: f.joining_date,
          notes: f.notes.trim() || null,
        })
        toast.success('Member updated')
        onSaved?.()
      } else {
        const res = await addMember({ ...f, phone: cleanPhone(f.phone) })
        toast.success(`${f.name.trim()} added`)
        onSaved?.(res)
      }
      onClose()
    } catch (x) {
      toast.error(x.message)
    } finally {
      setBusy(false)
    }
  }

  if (!edit && plans.length === 0) {
    return (
      <Modal title="Add member" onClose={onClose}>
        <p className="text-sm text-neutral-300">
          You need at least one membership plan first. Go to Settings → Membership plans and add one.
        </p>
      </Modal>
    )
  }

  return (
    <Modal title={edit ? 'Edit member' : 'Add new member'} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Field label="Full name" error={err.name}>
          <input className={inputCls} value={f.name} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Rahul Sharma" autoFocus />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Mobile number" error={err.phone}>
            <input className={inputCls} value={f.phone} inputMode="numeric" onChange={(e) => set('phone', e.target.value)} placeholder="10-digit number" />
          </Field>
          <Field label="Joining date" error={err.joining_date}>
            <input type="date" className={inputCls} max={today()} value={f.joining_date} onChange={(e) => set('joining_date', e.target.value)} />
          </Field>
        </div>

        {!edit && (
          <>
            <Field label="Membership plan" error={err.plan_id}>
              <select className={inputCls} value={f.plan_id} onChange={(e) => onPlan(e.target.value)}>
                {plans.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} – {p.months} month{p.months > 1 ? 's' : ''} – {money(p.price)}
                  </option>
                ))}
              </select>
            </Field>
            {plan && f.joining_date && (
              <p className="-mt-2 text-xs text-neutral-400">
                Membership will expire on <b className="text-orange-400">{fmtDate(addMonths(f.joining_date, plan.months))}</b>
              </p>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Fee for this plan" error={err.fee_amount}>
                <input type="number" min="0" className={inputCls} value={f.fee_amount} onChange={(e) => set('fee_amount', e.target.value)} />
              </Field>
              <Field label="Amount paid now" error={err.paid_amount} hint="Leave empty if not paid yet">
                <input type="number" min="0" className={inputCls} value={f.paid_amount} onChange={(e) => set('paid_amount', e.target.value)} placeholder="0" />
              </Field>
            </div>
            <Field label="Payment method">
              <select className={inputCls} value={f.method} onChange={(e) => set('method', e.target.value)}>
                {METHODS.map((m) => (
                  <option key={m.value} value={m.value}>{m.label}</option>
                ))}
              </select>
            </Field>
          </>
        )}

        <Field label="Notes (optional)">
          <textarea className={inputCls} rows={2} value={f.notes} onChange={(e) => set('notes', e.target.value)} placeholder="Goals, injuries, trainer, etc." />
        </Field>

        <div className="flex justify-end gap-2 pt-1">
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn type="submit" disabled={busy}>{busy ? 'Saving…' : edit ? 'Save changes' : 'Add member'}</Btn>
        </div>
      </form>
    </Modal>
  )
}
