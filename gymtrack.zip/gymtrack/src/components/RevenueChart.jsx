import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useData } from '../context/DataContext'

export default function RevenueChart({ data, height = 220 }) {
  const { money } = useData()
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
        <CartesianGrid stroke="#262626" vertical={false} />
        <XAxis dataKey="label" stroke="#737373" tickLine={false} axisLine={false} fontSize={12} />
        <YAxis
          stroke="#737373"
          tickLine={false}
          axisLine={false}
          width={44}
          fontSize={12}
          tickFormatter={(v) => (v >= 1000 ? `${v / 1000}k` : v)}
        />
        <Tooltip
          cursor={{ fill: 'rgba(255,255,255,0.06)' }}
          contentStyle={{ background: '#171717', border: '1px solid #404040', borderRadius: 8, color: '#fff' }}
          labelStyle={{ color: '#a3a3a3' }}
          formatter={(v) => [money(v), 'Collected']}
        />
        <Bar dataKey="revenue" fill="#f97316" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}
