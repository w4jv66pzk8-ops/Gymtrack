import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { X, MessageCircle, Loader2 } from 'lucide-react'

export const inputCls =
  'w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500'

const variants = {
  primary: 'bg-orange-500 hover:bg-orange-600 text-white',
  ghost: 'bg-neutral-800 hover:bg-neutral-700 text-neutral-100',
  outline: 'border border-neutral-700 hover:border-orange-500 text-neutral-200',
  danger: 'bg-red-600/90 hover:bg-red-600 text-white',
}

export function Btn({ variant = 'primary', size = 'md', className = '', ...p }) {
  const sz = size === 'sm' ? 'px-2.5 py-1.5 text-xs' : 'px-4 py-2.5 text-sm'
  return (
    <button
      type="button"
      {...p}
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg font-medium transition disabled:cursor-not-allowed disabled:opacity-50 ${sz} ${variants[variant]} ${className}`}
    />
  )
}

export function WaBtn({ href, label = 'WhatsApp', size = 'sm' }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className={`inline-flex items-center gap-1.5 rounded-lg bg-green-600 font-medium text-white transition hover:bg-green-700 ${
        size === 'sm' ? 'px-2.5 py-1.5 text-xs' : 'px-4 py-2.5 text-sm'
      }`}
    >
      <MessageCircle size={14} />
      {label}
    </a>
  )
}

export const Card = ({ className = '', children }) => (
  <div className={`rounded-2xl border border-neutral-800 bg-neutral-900/60 ${className}`}>{children}</div>
)

const tones = {
  gray: 'bg-neutral-800 text-neutral-300',
  green: 'bg-green-500/15 text-green-400',
  red: 'bg-red-500/15 text-red-400',
  amber: 'bg-amber-500/15 text-amber-400',
  orange: 'bg-orange-500/15 text-orange-400',
  blue: 'bg-blue-500/15 text-blue-400',
}
export const Badge = ({ tone = 'gray', children }) => (
  <span className={`inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium ${tones[tone]}`}>
    {children}
  </span>
)

export const PayBadge = ({ status }) => (
  <Badge tone={{ paid: 'green', partial: 'amber', unpaid: 'red' }[status]}>
    {{ paid: 'Paid', partial: 'Partially paid', unpaid: 'Unpaid' }[status]}
  </Badge>
)

export function MemBadge({ m }) {
  if (m.status === 'inactive') return <Badge>Inactive</Badge>
  if (m.mstate === 'expired') return <Badge tone="red">Expired {-m.daysLeft}d ago</Badge>
  if (m.mstate === 'expiring')
    return <Badge tone="orange">{m.daysLeft === 0 ? 'Expires today' : `Expires in ${m.daysLeft}d`}</Badge>
  return <Badge tone="green">Active</Badge>
}

export function Avatar({ name }) {
  const initials = name
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()
  return (
    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-orange-500/15 text-sm font-bold text-orange-400">
      {initials}
    </div>
  )
}

export function MemberLine({ m, sub, actions }) {
  return (
    <div className="flex flex-wrap items-center gap-3 py-3">
      <Avatar name={m.name} />
      <div className="min-w-0 flex-1 basis-40">
        <Link to={`/members/${m.id}`} className="block truncate font-medium hover:text-orange-400">
          {m.name}
        </Link>
        <div className="truncate text-xs text-neutral-400">{sub}</div>
      </div>
      <div className="flex flex-wrap items-center gap-2">{actions}</div>
    </div>
  )
}

export function StatCard({ icon: Icon, label, value, sub, to, accent }) {
  const body = (
    <div
      className={`h-full rounded-2xl border bg-neutral-900/60 p-4 transition ${
        accent ? 'border-orange-500/40' : 'border-neutral-800'
      } ${to ? 'hover:border-orange-500' : ''}`}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-neutral-400">{label}</span>
        {Icon && <Icon size={18} className="text-orange-500" />}
      </div>
      <div className="mt-2 text-2xl font-bold text-white">{value}</div>
      {sub && <div className="mt-1 text-xs text-neutral-500">{sub}</div>}
    </div>
  )
  return to ? <Link to={to}>{body}</Link> : body
}

export function PageHeader({ title, sub, children }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold text-white">{title}</h1>
        {sub && <p className="mt-0.5 text-sm text-neutral-400">{sub}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  )
}

export const Empty = ({ text }) => (
  <div className="px-4 py-10 text-center text-sm text-neutral-500">{text}</div>
)

export const Spinner = () => <Loader2 className="animate-spin text-orange-500" size={28} />

export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="mb-4 flex gap-1 overflow-x-auto rounded-xl bg-neutral-900 p-1">
      {tabs.map((t) => (
        <button
          key={t.id}
          type="button"
          onClick={() => onChange(t.id)}
          className={`whitespace-nowrap rounded-lg px-3.5 py-2 text-sm font-medium transition ${
            value === t.id ? 'bg-orange-500 text-white' : 'text-neutral-400 hover:text-white'
          }`}
        >
          {t.label}
          {t.count != null && <span className="ml-1.5 text-xs opacity-80">{t.count}</span>}
        </button>
      ))}
    </div>
  )
}

export function Field({ label, error, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-neutral-400">{label}</span>
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-neutral-500">{hint}</span>}
      {error && <span className="mt-1 block text-xs text-red-400">{error}</span>}
    </label>
  )
}

export function Modal({ title, onClose, children, wide }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [onClose])

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/75 sm:items-center sm:p-4"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className={`max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border border-neutral-800 bg-neutral-950 sm:rounded-2xl ${
          wide ? 'sm:max-w-2xl' : 'sm:max-w-lg'
        }`}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-neutral-800 bg-neutral-950 px-5 py-4">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button type="button" onClick={onClose} className="text-neutral-400 hover:text-white">
            <X size={20} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  )
}

export const METHODS = [
  { value: 'cash', label: 'Cash' },
  { value: 'upi', label: 'UPI' },
  { value: 'card', label: 'Card' },
  { value: 'bank', label: 'Bank transfer' },
]
