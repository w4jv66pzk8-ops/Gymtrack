import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { CheckCircle2, XCircle } from 'lucide-react'

const Ctx = createContext(null)
export const useToast = () => useContext(Ctx)

export function ToastProvider({ children }) {
  const [items, setItems] = useState([])

  const push = useCallback((type, msg) => {
    const id = Math.random()
    setItems((i) => [...i, { id, type, msg }])
    setTimeout(() => setItems((i) => i.filter((x) => x.id !== id)), 3800)
  }, [])

  const api = useMemo(
    () => ({ success: (m) => push('ok', m), error: (m) => push('err', m) }),
    [push]
  )

  return (
    <Ctx.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-3 z-[100] flex flex-col items-center gap-2 px-3">
        {items.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto flex max-w-md items-center gap-2 rounded-xl border px-4 py-3 text-sm shadow-lg ${
              t.type === 'ok'
                ? 'border-green-700 bg-green-950 text-green-100'
                : 'border-red-700 bg-red-950 text-red-100'
            }`}
          >
            {t.type === 'ok' ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
            {t.msg}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  )
}
