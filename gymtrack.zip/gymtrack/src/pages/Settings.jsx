import { useRef, useState } from 'react'
import { Database, Download, LogOut, Pencil, Plus, Trash2, Upload } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useData } from '../context/DataContext'
import { useToast } from '../components/Toast'
import { Btn, Card, Empty, Field, Modal, PageHeader, inputCls } from '../components/UI'
import { download, membersCSV, paymentsCSV, today } from '../lib/utils'

function PlanForm({ plan, onClose }) {
  const { addPlan, updatePlan } = useData()
  const toast = useToast()
  const [f, setF] = useState({ name: plan?.name || '', months: plan?.months ?? 1, price: plan?.price ?? '' })
  const [err, setErr] = useState({})
  const [busy, setBusy] = useState(false)
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }))

  const submit = async (e) => {
    e.preventDefault()
    const v = {}
    if (f.name.trim().length < 2) v.name = 'Enter a plan name'
    const months = Number(f.months)
    if (!Number.isInteger(months) || months < 1 || months > 60) v.months = 'Enter 1 to 60 months'
    if (f.price === '' || isNaN(Number(f.price)) || Number(f.price) < 0) v.price = 'Enter the plan price'
    setErr(v)
    if (Object.keys(v).length) return
    setBusy(true)
    try {
      if (plan) await updatePlan(plan.id, f)
      else await addPlan(f)
      toast.success(plan ? 'Plan updated' : 'Plan added')
      onClose()
    } catch (x) {
      toast.error(x.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal title={plan ? 'Edit plan' : 'Add plan'} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Field label="Plan name" error={err.name}>
          <input className={inputCls} value={f.name} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Quarterly" autoFocus />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Duration (months)" error={err.months}>
            <input type="number" min="1" className={inputCls} value={f.months} onChange={(e) => set('months', e.target.value)} />
          </Field>
          <Field label="Price" error={err.price}>
            <input type="number" min="0" className={inputCls} value={f.price} onChange={(e) => set('price', e.target.value)} />
          </Field>
        </div>
        {plan && <p className="text-xs text-neutral-500">Changing a plan does not affect existing members. Use Renew or Change plan on a member.</p>}
        <div className="flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save plan'}</Btn>
        </div>
      </form>
    </Modal>
  )
}

export default function SettingsPage() {
  const { session, signOut } = useAuth()
  const { settings, plans, members, payments, memberById, saveSettings, deletePlan, backup, restore, money } = useData()
  const toast = useToast()
  const fileRef = useRef(null)
  const [f, setF] = useState({ ...settings })
  const [err, setErr] = useState({})
  const [saving, setSaving] = useState(false)
  const [planModal, setPlanModal] = useState(null) // null | 'new' | plan
  const [busy, setBusy] = useState(false)
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }))

  const save = async (e) => {
    e.preventDefault()
    const v = {}
    if (!f.gym_name.trim()) v.gym_name = 'Enter your gym name'
    if (!f.currency.trim()) v.currency = 'Required'
    if (!/^\d{1,4}$/.test(String(f.country_code))) v.country_code = 'Digits only, e.g. 91'
    const days = Number(f.expiry_alert_days)
    if (!Number.isInteger(days) || days < 1 || days > 60) v.expiry_alert_days = 'Enter 1 to 60'
    ;['renewal_template', 'followup_template', 'fee_template'].forEach((k) => {
      if (!String(f[k]).trim()) v[k] = 'Message cannot be empty'
    })
    setErr(v)
    if (Object.keys(v).length) return
    setSaving(true)
    try {
      await saveSettings({
        gym_name: f.gym_name.trim(),
        owner_name: f.owner_name?.trim() || '',
        phone: f.phone?.trim() || '',
        address: f.address?.trim() || '',
        currency: f.currency.trim(),
        country_code: String(f.country_code),
        expiry_alert_days: days,
        renewal_template: f.renewal_template,
        followup_template: f.followup_template,
        fee_template: f.fee_template,
      })
      toast.success('Settings saved')
    } catch (x) {
      toast.error(x.message)
    } finally {
      setSaving(false)
    }
  }

  const removePlan = async (p) => {
    if (!window.confirm(`Delete plan "${p.name}"? Existing members keep their current plan details.`)) return
    try {
      await deletePlan(p.id)
      toast.success('Plan deleted')
    } catch (x) {
      toast.error(x.message)
    }
  }

  const doBackup = async () => {
    setBusy(true)
    try {
      const data = await backup()
      download(`gymtrack-backup-${today()}.json`, JSON.stringify(data, null, 2), 'application/json')
      toast.success('Backup downloaded')
    } catch (x) {
      toast.error(x.message)
    } finally {
      setBusy(false)
    }
  }

  const doRestore = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    try {
      const data = JSON.parse(await file.text())
      if (!window.confirm('Restore this backup? Records in the file will be added, and records with the same ID will be overwritten.')) return
      setBusy(true)
      await restore(data)
      toast.success('Backup restored')
    } catch (x) {
      toast.error(x instanceof SyntaxError ? 'That file is not valid JSON' : x.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <PageHeader title="Settings" sub="Gym details, plans, messages and data" />

      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="p-5 lg:col-span-2">
          <h2 className="mb-4 font-semibold">Gym details & WhatsApp messages</h2>
          <form onSubmit={save} className="space-y-4" noValidate>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Gym name" error={err.gym_name}>
                <input className={inputCls} value={f.gym_name} onChange={(e) => set('gym_name', e.target.value)} />
              </Field>
              <Field label="Owner name">
                <input className={inputCls} value={f.owner_name || ''} onChange={(e) => set('owner_name', e.target.value)} />
              </Field>
              <Field label="Gym phone (shown on receipts)">
                <input className={inputCls} value={f.phone || ''} onChange={(e) => set('phone', e.target.value)} />
              </Field>
              <Field label="Address (shown on receipts)">
                <input className={inputCls} value={f.address || ''} onChange={(e) => set('address', e.target.value)} />
              </Field>
              <Field label="Currency symbol" error={err.currency}>
                <input className={inputCls} value={f.currency} onChange={(e) => set('currency', e.target.value)} />
              </Field>
              <Field label="Country code for WhatsApp" error={err.country_code} hint="91 for India">
                <input className={inputCls} value={f.country_code} inputMode="numeric" onChange={(e) => set('country_code', e.target.value)} />
              </Field>
              <Field label="Renewal alert (days before expiry)" error={err.expiry_alert_days}>
                <input type="number" min="1" max="60" className={inputCls} value={f.expiry_alert_days} onChange={(e) => set('expiry_alert_days', e.target.value)} />
              </Field>
            </div>
            <p className="text-xs text-neutral-500">
              In messages you can use <code className="text-orange-400">{'{name} {gym} {expiry} {days} {amount}'}</code>
            </p>
            <Field label="Renewal reminder message" error={err.renewal_template}>
              <textarea rows={3} className={inputCls} value={f.renewal_template} onChange={(e) => set('renewal_template', e.target.value)} />
            </Field>
            <Field label="Missing member follow-up message" error={err.followup_template}>
              <textarea rows={3} className={inputCls} value={f.followup_template} onChange={(e) => set('followup_template', e.target.value)} />
            </Field>
            <Field label="Fee reminder message" error={err.fee_template}>
              <textarea rows={3} className={inputCls} value={f.fee_template} onChange={(e) => set('fee_template', e.target.value)} />
            </Field>
            <div className="flex justify-end">
              <Btn type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save settings'}</Btn>
            </div>
          </form>
        </Card>

        <Card className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">Membership plans</h2>
            <Btn size="sm" onClick={() => setPlanModal('new')}><Plus size={14} /> Add plan</Btn>
          </div>
          {plans.length === 0 ? (
            <Empty text="No plans yet. Add your first plan." />
          ) : (
            <div className="divide-y divide-neutral-800">
              {plans.map((p) => (
                <div key={p.id} className="flex items-center justify-between gap-3 py-3">
                  <div>
                    <div className="font-medium">{p.name}</div>
                    <div className="text-xs text-neutral-400">{p.months} month{p.months > 1 ? 's' : ''} · {money(p.price)}</div>
                  </div>
                  <div className="flex gap-2">
                    <Btn size="sm" variant="ghost" onClick={() => setPlanModal(p)}><Pencil size={13} /> Edit</Btn>
                    <Btn size="sm" variant="danger" onClick={() => removePlan(p)}><Trash2 size={13} /></Btn>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-5">
          <h2 className="mb-3 font-semibold">Export & backup</h2>
          <p className="mb-3 text-sm text-neutral-400">
            CSV files open directly in Excel. A backup file contains everything and can be restored later.
          </p>
          <div className="flex flex-wrap gap-2">
            <Btn variant="outline" onClick={() => download(`gymtrack-members-${today()}.csv`, membersCSV(members))}>
              <Download size={16} /> Members CSV
            </Btn>
            <Btn variant="outline" onClick={() => download(`gymtrack-payments-${today()}.csv`, paymentsCSV(payments, memberById))}>
              <Download size={16} /> Payments CSV
            </Btn>
            <Btn onClick={doBackup} disabled={busy}><Database size={16} /> Download backup</Btn>
            <Btn variant="ghost" onClick={() => fileRef.current?.click()} disabled={busy}>
              <Upload size={16} /> Restore backup
            </Btn>
            <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={doRestore} />
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <h2 className="mb-3 font-semibold">Account</h2>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="text-sm text-neutral-400">
              Signed in as <b className="text-white">{session?.user?.email}</b>
            </div>
            <Btn variant="outline" onClick={signOut}><LogOut size={16} /> Sign out</Btn>
          </div>
        </Card>
      </div>

      {planModal && <PlanForm plan={planModal === 'new' ? null : planModal} onClose={() => setPlanModal(null)} />}
    </>
  )
}
