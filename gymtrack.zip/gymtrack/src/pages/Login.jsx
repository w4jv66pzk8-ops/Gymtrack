import { useState } from 'react'
import { Dumbbell } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { Btn, Field, inputCls } from '../components/UI'

export default function Login() {
  const { signIn, signUp } = useAuth()
  const [mode, setMode] = useState('in')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const [info, setInfo] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setErr('')
    setInfo('')
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr('Enter a valid email address')
    if (password.length < 6) return setErr('Password must be at least 6 characters')
    setBusy(true)
    const { data, error } = mode === 'in' ? await signIn(email, password) : await signUp(email, password)
    setBusy(false)
    if (error) return setErr(error.message)
    if (mode === 'up' && !data.session) setInfo('Account created. Check your email to confirm it, then sign in.')
  }

  return (
    <div className="relative grid min-h-screen place-items-center overflow-hidden px-4">
      <div className="pointer-events-none absolute -top-40 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-orange-500/20 blur-3xl" />
      <div className="relative w-full max-w-sm rounded-2xl border border-neutral-800 bg-neutral-900/70 p-6 shadow-2xl backdrop-blur">
        <div className="mb-6 flex flex-col items-center gap-2">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-orange-500">
            <Dumbbell size={30} className="text-white" />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">
            GYM<span className="text-orange-500">TRACK</span>
          </h1>
          <p className="text-sm text-neutral-400">
            {mode === 'in' ? 'Sign in to manage your gym' : 'Create the admin account'}
          </p>
        </div>

        <form onSubmit={submit} className="space-y-4" noValidate>
          <Field label="Email">
            <input type="email" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </Field>
          <Field label="Password">
            <input
              type="password"
              className={inputCls}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === 'in' ? 'current-password' : 'new-password'}
            />
          </Field>
          {err && <p className="text-sm text-red-400">{err}</p>}
          {info && <p className="text-sm text-green-400">{info}</p>}
          <Btn type="submit" className="w-full" disabled={busy}>
            {busy ? 'Please wait…' : mode === 'in' ? 'Sign in' : 'Create account'}
          </Btn>
        </form>

        <button
          type="button"
          className="mt-4 w-full text-center text-xs text-neutral-400 hover:text-orange-400"
          onClick={() => {
            setMode(mode === 'in' ? 'up' : 'in')
            setErr('')
            setInfo('')
          }}
        >
          {mode === 'in' ? 'First time? Create the admin account' : 'Already have an account? Sign in'}
        </button>
      </div>
    </div>
  )
}
