import { useMemo, useState } from 'react'
import { CalendarCheck, UserCheck, UserMinus } from 'lucide-react'
import { useData } from '../context/DataContext'
import { useToast } from '../components/Toast'
import { Btn, Card, Empty, MemberLine, PageHeader, StatCard, Tabs, WaBtn } from '../components/UI'
import { fmtDate, today } from '../lib/utils'

const BUCKETS = [3, 7, 15, 30]
const BANDS = [
  { label: '3–6 days', min: 3, max: 6, cls: 'bg-amber-400' },
  { label: '7–14 days', min: 7, max: 14, cls: 'bg-orange-500' },
  { label: '15–29 days', min: 15, max: 29, cls: 'bg-red-500' },
  { label: '30+ days', min: 30, max: Infinity, cls: 'bg-red-800' },
]

export default function Missing() {
  const { members, waFor, setStatus, markAttendance } = useData()
  const toast = useToast()
  const [tab, setTab] = useState('absent')
  const [th, setTh] = useState(3)

  const live = useMemo(() => members.filter((m) => m.status === 'active'), [members])
  const marked = useMemo(
    () => members.filter((m) => m.status === 'inactive').sort((a, b) => b.absent - a.absent),
    [members]
  )
  const counts = useMemo(() => BUCKETS.map((n) => live.filter((m) => m.absent >= n).length), [live])
  const bands = useMemo(
    () => BANDS.map((b) => ({ ...b, n: live.filter((m) => m.absent >= b.min && m.absent <= b.max).length })),
    [live]
  )
  const list = useMemo(() => live.filter((m) => m.absent >= th).sort((a, b) => b.absent - a.absent), [live, th])
  const rows = tab === 'absent' ? list : marked

  const run = async (fn, msg) => {
    try {
      await fn()
      toast.success(msg)
    } catch (x) {
      toast.error(x.message)
    }
  }

  return (
    <>
      <PageHeader title="Missing members" sub="Active members who stopped coming to the gym" />

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
        {BUCKETS.map((n, i) => (
          <button
            key={n}
            type="button"
            className="text-left"
            onClick={() => {
              setTh(n)
              setTab('absent')
            }}
          >
            <div className={`rounded-2xl ${th === n && tab === 'absent' ? 'ring-2 ring-orange-500' : ''}`}>
              <StatCard label={`Absent ${n}+ days`} value={counts[i]} />
            </div>
          </button>
        ))}
        <StatCard label="Marked inactive" value={marked.length} />
      </div>

      <Card className="mb-5 p-4">
        <div className="mb-2 text-sm font-semibold">Absence breakdown</div>
        {live.length > 0 && (
          <div className="flex h-3 overflow-hidden rounded-full bg-neutral-800">
            {bands.map((b) => (
              <div key={b.label} className={b.cls} style={{ width: `${(b.n / live.length) * 100}%` }} title={`${b.label}: ${b.n}`} />
            ))}
          </div>
        )}
        <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-neutral-400">
          {bands.map((b) => (
            <span key={b.label} className="inline-flex items-center gap-1.5">
              <span className={`h-2.5 w-2.5 rounded-full ${b.cls}`} /> {b.label}: <b className="text-white">{b.n}</b>
            </span>
          ))}
          <span>
            Attending regularly (under 3 days): <b className="text-white">{live.filter((m) => m.absent < 3).length}</b>
          </span>
        </div>
      </Card>

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { id: 'absent', label: `Absent ${th}+ days`, count: list.length },
          { id: 'marked', label: 'Marked inactive', count: marked.length },
        ]}
      />

      <Card className="px-4">
        {rows.length === 0 ? (
          <Empty text={tab === 'absent' ? 'Nobody is missing for this long 💪' : 'No members are marked inactive'} />
        ) : (
          <div className="divide-y divide-neutral-800">
            {rows.map((m) => (
              <MemberLine
                key={m.id}
                m={m}
                sub={`Last visit: ${m.last_visit ? fmtDate(m.last_visit) : 'never'} · ${m.plan_name}`}
                actions={
                  <>
                    <span className="text-sm font-semibold text-red-400">{m.absent} days</span>
                    <WaBtn href={waFor('followup', m)} label="Follow up" />
                    {m.status === 'active' ? (
                      <>
                        <Btn size="sm" variant="ghost" onClick={() => run(() => markAttendance(m, today()), `${m.name} marked present`)}>
                          <CalendarCheck size={13} /> Present today
                        </Btn>
                        <Btn size="sm" variant="outline" onClick={() => run(() => setStatus(m.id, 'inactive'), `${m.name} marked inactive`)}>
                          <UserMinus size={13} /> Inactive
                        </Btn>
                      </>
                    ) : (
                      <Btn size="sm" onClick={() => run(() => setStatus(m.id, 'active'), `${m.name} marked active`)}>
                        <UserCheck size={13} /> Mark active
                      </Btn>
                    )}
                  </>
                }
              />
            ))}
          </div>
        )}
      </Card>
    </>
  )
}
