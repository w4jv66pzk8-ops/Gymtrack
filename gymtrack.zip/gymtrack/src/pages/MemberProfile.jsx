import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, Pencil, Phone, RefreshCw, Repeat, Trash2, UserCheck, UserMinus, Wallet } from 'lucide-react'
import { useData } from '../context/DataContext'
import { useToast } from '../components/Toast'
import { Badge, Btn, Card, Empty, Field, MemBadge, Modal, PayBadge, WaBtn, inputCls } from '../components/UI'
import MemberForm from '../components/MemberForm'
import PaymentModal from '../components/PaymentModal'
import RenewModal from '../components/RenewModal'
import Receipt from '../components/Receipt'
import { addDays, addMonths, fmtDate, fmtTime, receiptNo, today, waLink } from '../lib/utils'

function ChangePlanModal({ member, onClose }) {
  const { plans, changePlan, money } = useData()
  const toast = useToast()
  const first = plans.find((p) => p.id === member.plan_id) || plans[0]
  const [planId, setPlanId] = useState(first?.id || '')
  const [fee, setFee] = useState(first ? first.price : '')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const plan = plans.find((p) => p.id === planId)

  const onPlan = (id) => {
    setPlanId(id)
    const p = plans.find((x) => x.id === id)
    if (p) setFee(p.price)
  }

  const submit = async (e) => {
    e.preventDefault()
    if (!planId) return setErr('Choose a plan')
    if (fee === '' || isNaN(Number(fee)) || Number(fee) < 0) return setErr('Enter a valid fee')
    setBusy(true)
    try {
      await changePlan(member, planId, fee)
      toast.success('Plan updated')
      onClose()
    } catch (x) {
      toast.error(x.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal title="Change membership plan" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <p className="text-sm text-neutral-400">
          This changes the plan for the <b>current period</b> (started {fmtDate(member.cycle_start)}). Amounts already paid are kept.
        </p>
        <Field label="New plan">
          <select className={inputCls} value={planId} onChange={(e) => onPlan(e.target.value)}>
            {plans.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} – {p.months} month{p.months > 1 ? 's' : ''} – {money(p.price)}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Fee for this period" error={err}>
          <input type="number" min="0" className={inputCls} value={fee} onChange={(e) => setFee(e.target.value)} />
        </Field>
        {plan && (
          <p className="text-xs text-neutral-400">
            New expiry date: <b className="text-orange-400">{fmtDate(addMonths(member.cycle_start, plan.months))}</b>
          </p>
        )}
        <div className="flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn type="submit" disabled={busy}>{busy ? 'Saving…' : 'Update plan'}</Btn>
        </div>
      </form>
    </Modal>
  )
}

const Info = ({ label, children }) => (
  <div>
    <div className="text-xs uppercase tracking-wide text-neutral-500">{label}</div>
    <div className="mt-1 text-sm font-medium">{children}</div>
  </div>
)

export default function MemberProfile() {
  const { id } = useParams()
  const nav = useNavigate()
  const toast = useToast()
  const { memberById, payments, renewals, attendance, settings, money, waFor, setStatus, deleteMember } = useData()
  const m = memberById[id]
  const [modal, setModal] = useState(null) // 'edit' | 'pay' | 'renew' | 'plan'
  const [receipt, setReceipt] = useState(null)

  const myPayments = useMemo(() => payments.filter((p) => p.member_id === id), [payments, id])
  const myRenewals = useMemo(() => renewals.filter((r) => r.member_id === id), [renewals, id])
  const visits = useMemo(() => {
    const mine = attendance.filter((a) => a.member_id === id)
    return { set: new Set(mine.map((a) => a.visit_date)), rows: mine }
  }, [attendance, id])

  if (!m)
    return (
      <div className="py-20 text-center text-neutral-400">
        Member not found. <Link to="/members" className="text-orange-400">Back to members</Link>
      </div>
    )

  const t = today()
  const grid = Array.from({ length: 28 }, (_, i) => addDays(t, i - 27))
  const last30 = grid.filter((d) => visits.set.has(d)).length

  const toggleStatus = async () => {
    try {
      await setStatus(m.id, m.status === 'active' ? 'inactive' : 'active')
      toast.success(`Marked ${m.status === 'active' ? 'inactive' : 'active'}`)
    } catch (x) {
      toast.error(x.message)
    }
  }
  const remove = async () => {
    if (!window.confirm(`Delete ${m.name}? Their payments, renewals and attendance will also be deleted. This cannot be undone.`)) return
    try {
      await deleteMember(m.id)
      toast.success('Member deleted')
      nav('/members')
    } catch (x) {
      toast.error(x.message)
    }
  }

  return (
    <>
      <Link to="/members" className="mb-3 inline-flex items-center gap-1 text-sm text-neutral-400 hover:text-white">
        <ArrowLeft size={16} /> Members
      </Link>

      <Card className="p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">{m.name}</h1>
            <a href={`tel:${m.phone}`} className="mt-1 inline-flex items-center gap-1.5 text-sm text-neutral-400 hover:text-orange-400">
              <Phone size={14} /> {m.phone}
            </a>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <PayBadge status={m.pay} />
              <MemBadge m={m} />
              {m.absent >= 3 && m.status === 'active' && <Badge tone="red">Absent {m.absent} days</Badge>}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {m.due > 0 && <Btn onClick={() => setModal('pay')}><Wallet size={16} /> Collect {money(m.due)}</Btn>}
            <Btn variant={m.due > 0 ? 'outline' : 'primary'} onClick={() => setModal('renew')}><RefreshCw size={16} /> Renew</Btn>
            <Btn variant="outline" onClick={() => setModal('plan')}><Repeat size={16} /> Change plan</Btn>
            <Btn variant="outline" onClick={() => setModal('edit')}><Pencil size={16} /> Edit</Btn>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-4 border-t border-neutral-800 pt-4 sm:grid-cols-4">
          <Info label="Plan">{m.plan_name}</Info>
          <Info label="Joined">{fmtDate(m.joining_date)}</Info>
          <Info label="Valid till">{fmtDate(m.expiry_date)}</Info>
          <Info label="Last visit">{m.last_visit ? `${fmtDate(m.last_visit)} (${m.absent}d ago)` : 'Never'}</Info>
          <Info label="Fee this period">{money(m.cycle_fee)}</Info>
          <Info label="Paid">{money(m.cycle_paid)}</Info>
          <Info label="Pending"><span className={m.due > 0 ? 'text-orange-400' : 'text-green-400'}>{money(m.due)}</span></Info>
          <Info label="Status">{m.status === 'active' ? 'Active' : 'Inactive'}</Info>
        </div>
        {m.notes && <p className="mt-4 rounded-lg bg-neutral-900 p-3 text-sm text-neutral-300">{m.notes}</p>}

        <div className="mt-5 flex flex-wrap gap-2 border-t border-neutral-800 pt-4">
          {m.due > 0 && <WaBtn href={waFor('fee', m)} label="Fee reminder" />}
          {m.mstate !== 'active' && <WaBtn href={waFor('renewal', m)} label="Renewal reminder" />}
          {m.absent >= 3 && <WaBtn href={waFor('followup', m)} label="Follow up" />}
          <WaBtn href={waLink(m.phone, '', settings.country_code)} label="Open chat" />
          <Btn size="sm" variant="ghost" onClick={toggleStatus}>
            {m.status === 'active' ? <><UserMinus size={14} /> Mark inactive</> : <><UserCheck size={14} /> Mark active</>}
          </Btn>
          <Btn size="sm" variant="danger" onClick={remove}><Trash2 size={14} /> Delete</Btn>
        </div>
      </Card>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Card className="p-4">
          <h2 className="mb-3 font-semibold">Payment history</h2>
          {myPayments.length === 0 ? (
            <Empty text="No payments yet" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {myPayments.map((p) => (
                <div key={p.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                  <div>
                    <div className="font-medium">{money(p.amount)}</div>
                    <div className="text-xs text-neutral-400">
                      {fmtDate(p.paid_on)} · {p.method.toUpperCase()} · {receiptNo(p.receipt_no)}
                      {p.note ? ` · ${p.note}` : ''}
                    </div>
                  </div>
                  <Btn size="sm" variant="ghost" onClick={() => setReceipt(p)}>Receipt</Btn>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-4">
          <h2 className="mb-3 font-semibold">Renewal history</h2>
          {myRenewals.length === 0 ? (
            <Empty text="No renewals yet" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {myRenewals.map((r) => (
                <div key={r.id} className="py-2.5 text-sm">
                  <div className="font-medium">{r.plan_name} · {money(r.amount)}</div>
                  <div className="text-xs text-neutral-400">
                    Renewed {fmtDate(r.renewed_on)} · {fmtDate(r.old_expiry)} → {fmtDate(r.new_expiry)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-4 lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">Attendance · last 28 days</h2>
            <span className="text-xs text-neutral-400">{last30} visits</span>
          </div>
          <div className="grid grid-cols-7 gap-1.5 sm:max-w-md">
            {grid.map((d) => (
              <div
                key={d}
                title={`${fmtDate(d)}${visits.set.has(d) ? ' – present' : ''}`}
                className={`grid aspect-square place-items-center rounded-md text-[10px] ${
                  visits.set.has(d) ? 'bg-orange-500 font-bold text-white' : 'bg-neutral-900 text-neutral-600'
                }`}
              >
                {Number(d.slice(8))}
              </div>
            ))}
          </div>
          {visits.rows.length > 0 && (
            <p className="mt-3 text-xs text-neutral-500">
              Latest check-in: {fmtDate(visits.rows[0].visit_date)} {fmtTime(visits.rows[0].checked_in_at)}
            </p>
          )}
        </Card>
      </div>

      {modal === 'edit' && <MemberForm member={m} onClose={() => setModal(null)} />}
      {modal === 'pay' && <PaymentModal member={m} onClose={() => setModal(null)} onDone={setReceipt} />}
      {modal === 'renew' && <RenewModal member={m} onClose={() => setModal(null)} onDone={(p) => p && setReceipt(p)} />}
      {modal === 'plan' && <ChangePlanModal member={m} onClose={() => setModal(null)} />}
      {receipt && <Receipt payment={receipt} onClose={() => setReceipt(null)} />}
    </>
  )
}
