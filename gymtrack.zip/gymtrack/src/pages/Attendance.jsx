import { useMemo, useState } from 'react'
import { Check } from 'lucide-react'
import { useData } from '../context/DataContext'
import { useToast } from '../components/Toast'
import { Avatar, Badge, Btn, Card, Empty, PageHeader, StatCard, inputCls } from '../components/UI'
import { fmtDate, fmtTime, today } from '../lib/utils'

export default function Attendance() {
  const { members, attendance, markAttendance, unmarkAttendance } = useData()
  const toast = useToast()
  const [date, setDate] = useState(today())
  const [q, setQ] = useState('')
  const [show, setShow] = useState('all')
  const [busyId, setBusyId] = useState(null)

  const present = useMemo(
    () => new Map(attendance.filter((a) => a.visit_date === date).map((a) => [a.member_id, a])),
    [attendance, date]
  )

  const list = useMemo(() => {
    const s = q.trim().toLowerCase()
    return members
      .filter((m) => !s || m.name.toLowerCase().includes(s) || m.phone.includes(s))
      .filter((m) => (show === 'present' ? present.has(m.id) : show === 'absent' ? !present.has(m.id) : true))
      .sort((a, b) => (a.status === b.status ? a.name.localeCompare(b.name) : a.status === 'active' ? -1 : 1))
  }, [members, q, show, present])

  const activeCount = members.filter((m) => m.status === 'active').length
  const presentCount = present.size
  const pct = activeCount ? Math.round((presentCount / activeCount) * 100) : 0

  const toggle = async (m) => {
    setBusyId(m.id)
    try {
      if (present.has(m.id)) {
        await unmarkAttendance(m, date)
        toast.success(`${m.name} unmarked`)
      } else {
        await markAttendance(m, date)
        toast.success(`${m.name} marked present`)
      }
    } catch (x) {
      toast.error(x.message)
    } finally {
      setBusyId(null)
    }
  }

  return (
    <>
      <PageHeader title="Attendance register" sub={fmtDate(date)}>
        <input
          type="date"
          className={`${inputCls} w-auto`}
          value={date}
          max={today()}
          min={undefined}
          onChange={(e) => e.target.value && setDate(e.target.value)}
        />
        {date !== today() && <Btn variant="outline" onClick={() => setDate(today())}>Today</Btn>}
      </PageHeader>

      <div className="mb-5 grid grid-cols-3 gap-3">
        <StatCard label="Present" value={presentCount} accent />
        <StatCard label="Active members" value={activeCount} />
        <StatCard label="Turnout" value={`${pct}%`} />
      </div>

      <div className="mb-4 grid gap-2 sm:grid-cols-3">
        <input className={`${inputCls} sm:col-span-2`} placeholder="Search member to check in…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className={inputCls} value={show} onChange={(e) => setShow(e.target.value)}>
          <option value="all">Everyone</option>
          <option value="present">Present only</option>
          <option value="absent">Not yet present</option>
        </select>
      </div>

      <Card>
        {list.length === 0 ? (
          <Empty text="No members found" />
        ) : (
          <div className="divide-y divide-neutral-800">
            {list.map((m) => {
              const a = present.get(m.id)
              return (
                <div key={m.id} className="flex items-center gap-3 p-3 sm:p-4">
                  <Avatar name={m.name} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-medium">{m.name}</div>
                    <div className="flex flex-wrap items-center gap-1.5 text-xs text-neutral-400">
                      {a ? <span>In at {fmtTime(a.checked_in_at)}</span> : <span>Last visit {m.last_visit ? fmtDate(m.last_visit) : 'never'}</span>}
                      {m.mstate === 'expired' && m.status === 'active' && <Badge tone="red">Membership expired</Badge>}
                      {m.status === 'inactive' && <Badge>Inactive</Badge>}
                    </div>
                  </div>
                  <Btn
                    variant={a ? 'primary' : 'outline'}
                    size="sm"
                    disabled={busyId === m.id}
                    onClick={() => toggle(m)}
                    className="min-w-[96px]"
                  >
                    {a ? (<><Check size={14} /> Present</>) : 'Mark present'}
                  </Btn>
                </div>
              )
            })}
          </div>
        )}
      </Card>
      <p className="mt-3 text-xs text-neutral-500">
        Marking an inactive member present sets them back to active. Attendance is kept for the last 120 days in this view.
      </p>
    </>
  )
}
