import { useMemo, useState } from 'react'
import { useData } from '../context/DataContext'
import { Btn, Card, Empty, MemBadge, MemberLine, PageHeader, StatCard, Tabs, WaBtn, PayBadge } from '../components/UI'
import RenewModal from '../components/RenewModal'
import Receipt from '../components/Receipt'
import { Link } from 'react-router-dom'
import { fmtDate } from '../lib/utils'
import { Clock, RefreshCw, XCircle } from 'lucide-react'

const RANGES = [7, 15, 30]

export default function Renewals() {
  const { members, renewals, memberById, settings, money, waFor } = useData()
  const [tab, setTab] = useState('expiring')
  const [range, setRange] = useState(settings.expiry_alert_days)
  const [renewFor, setRenewFor] = useState(null)
  const [receipt, setReceipt] = useState(null)

  // Members marked inactive are left out of reminders
  const live = useMemo(() => members.filter((m) => m.status === 'active'), [members])
  const expiring = useMemo(
    () => live.filter((m) => m.daysLeft >= 0 && m.daysLeft <= range).sort((a, b) => a.daysLeft - b.daysLeft),
    [live, range]
  )
  const expired = useMemo(() => live.filter((m) => m.daysLeft < 0).sort((a, b) => b.daysLeft - a.daysLeft), [live])

  const rows = tab === 'expiring' ? expiring : expired

  return (
    <>
      <PageHeader title="Membership renewals" sub="Members marked inactive are hidden from reminders" />

      <div className="mb-5 grid grid-cols-2 gap-3">
        <StatCard icon={Clock} label={`Expiring in ${range} days`} value={expiring.length} accent />
        <StatCard icon={XCircle} label="Already expired" value={expired.length} />
      </div>

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { id: 'expiring', label: 'Expiring soon', count: expiring.length },
          { id: 'expired', label: 'Expired', count: expired.length },
          { id: 'history', label: 'Renewal history', count: renewals.length },
        ]}
      />

      {tab === 'expiring' && (
        <div className="mb-3 flex items-center gap-2 text-xs text-neutral-400">
          Show members expiring within
          {RANGES.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRange(r)}
              className={`rounded-full border px-3 py-1 font-medium ${
                range === r ? 'border-orange-500 bg-orange-500 text-white' : 'border-neutral-800 hover:border-neutral-600'
              }`}
            >
              {r} days
            </button>
          ))}
        </div>
      )}

      {tab !== 'history' ? (
        <Card className="px-4">
          {rows.length === 0 ? (
            <Empty text={tab === 'expiring' ? 'No memberships expiring in this period 🎉' : 'No expired memberships 🎉'} />
          ) : (
            <div className="divide-y divide-neutral-800">
              {rows.map((m) => (
                <MemberLine
                  key={m.id}
                  m={m}
                  sub={`${m.plan_name} · ends ${fmtDate(m.expiry_date)}${m.due > 0 ? ` · due ${money(m.due)}` : ''}`}
                  actions={
                    <>
                      <MemBadge m={m} />
                      {m.due > 0 && <PayBadge status={m.pay} />}
                      <WaBtn href={waFor('renewal', m)} label="Remind" />
                      <Btn size="sm" onClick={() => setRenewFor(m)}>
                        <RefreshCw size={13} /> Renew
                      </Btn>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Card>
      ) : (
        <Card className="px-4">
          {renewals.length === 0 ? (
            <Empty text="No renewals recorded yet" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {renewals.slice(0, 200).map((r) => {
                const m = memberById[r.member_id]
                return (
                  <div key={r.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
                    <div>
                      {m ? (
                        <Link to={`/members/${m.id}`} className="font-medium hover:text-orange-400">{m.name}</Link>
                      ) : (
                        <span className="font-medium">Deleted member</span>
                      )}
                      <div className="text-xs text-neutral-400">
                        {r.plan_name} · {fmtDate(r.old_expiry)} → {fmtDate(r.new_expiry)}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{money(r.amount)}</div>
                      <div className="text-xs text-neutral-500">{fmtDate(r.renewed_on)}</div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </Card>
      )}

      {renewFor && <RenewModal member={renewFor} onClose={() => setRenewFor(null)} onDone={(p) => p && setReceipt(p)} />}
      {receipt && <Receipt payment={receipt} onClose={() => setReceipt(null)} />}
    </>
  )
}
