import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Download } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Badge, Btn, Card, Empty, MemberLine, PageHeader, PayBadge, StatCard, Tabs, WaBtn, inputCls } from '../components/UI'
import PaymentModal from '../components/PaymentModal'
import Receipt from '../components/Receipt'
import RevenueChart from '../components/RevenueChart'
import { download, fmtDate, lastMonths, paymentsCSV, receiptNo, sumAmount, today } from '../lib/utils'

export default function Fees() {
  const { members, payments, memberById, money, waFor } = useData()
  const [tab, setTab] = useState('pending')
  const [q, setQ] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [method, setMethod] = useState('all')
  const [payFor, setPayFor] = useState(null)
  const [receipt, setReceipt] = useState(null)

  const t = today()
  const monthKey = t.slice(0, 7)
  const s = q.trim().toLowerCase()

  const pending = useMemo(
    () =>
      members
        .filter((m) => m.due > 0 && (!s || m.name.toLowerCase().includes(s) || m.phone.includes(s)))
        .sort((a, b) => b.due - a.due),
    [members, s]
  )
  const totalPending = useMemo(() => members.reduce((sum, m) => sum + m.due, 0), [members])

  const history = useMemo(
    () =>
      payments.filter((p) => {
        const m = memberById[p.member_id]
        if (s && !(m && (m.name.toLowerCase().includes(s) || m.phone.includes(s)))) return false
        if (from && p.paid_on < from) return false
        if (to && p.paid_on > to) return false
        if (method !== 'all' && p.method !== method) return false
        return true
      }),
    [payments, memberById, s, from, to, method]
  )

  const daily = useMemo(() => {
    const [y, mo] = monthKey.split('-').map(Number)
    const days = new Date(y, mo, 0).getDate()
    return Array.from({ length: days }, (_, i) => {
      const key = `${monthKey}-${String(i + 1).padStart(2, '0')}`
      return { label: String(i + 1), revenue: sumAmount(payments.filter((p) => p.paid_on === key)) }
    })
  }, [payments, monthKey])

  const monthly = useMemo(
    () =>
      lastMonths(12)
        .map((x) => {
          const rows = payments.filter((p) => p.paid_on.startsWith(x.key))
          return { ...x, revenue: sumAmount(rows), count: rows.length }
        })
        .reverse(),
    [payments]
  )

  const todayTotal = sumAmount(payments.filter((p) => p.paid_on === t))
  const monthTotal = sumAmount(payments.filter((p) => p.paid_on.startsWith(monthKey)))

  return (
    <>
      <PageHeader title="Fees register" sub="Collect payments, track dues and revenue">
        <Btn variant="outline" onClick={() => download(`gymtrack-payments-${t}.csv`, paymentsCSV(history, memberById))}>
          <Download size={16} /> Export payments
        </Btn>
      </PageHeader>

      <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard label="Today's collection" value={money(todayTotal)} accent />
        <StatCard label="This month" value={money(monthTotal)} />
        <StatCard label="Total pending" value={money(totalPending)} sub={`${members.filter((m) => m.due > 0).length} members`} />
      </div>

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { id: 'pending', label: 'Pending fees', count: pending.length },
          { id: 'history', label: 'Payment history', count: history.length },
          { id: 'revenue', label: 'Revenue' },
        ]}
      />

      {tab !== 'revenue' && (
        <div className="mb-4 grid gap-2 sm:grid-cols-4">
          <input
            className={`${inputCls} sm:col-span-2`}
            placeholder="Search by name or phone…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          {tab === 'history' && (
            <>
              <div className="flex items-center gap-2">
                <input type="date" className={inputCls} value={from} max={t} onChange={(e) => setFrom(e.target.value)} title="From" />
                <input type="date" className={inputCls} value={to} max={t} onChange={(e) => setTo(e.target.value)} title="To" />
              </div>
              <select className={inputCls} value={method} onChange={(e) => setMethod(e.target.value)}>
                <option value="all">All methods</option>
                <option value="cash">Cash</option>
                <option value="upi">UPI</option>
                <option value="card">Card</option>
                <option value="bank">Bank transfer</option>
              </select>
            </>
          )}
        </div>
      )}

      {tab === 'pending' && (
        <Card className="px-4">
          {pending.length === 0 ? (
            <Empty text="No pending payments 🎉" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {pending.map((m) => (
                <MemberLine
                  key={m.id}
                  m={m}
                  sub={`${m.plan_name} · paid ${money(m.cycle_paid)} of ${money(m.cycle_fee)}`}
                  actions={
                    <>
                      <PayBadge status={m.pay} />
                      <span className="text-sm font-semibold text-orange-400">{money(m.due)}</span>
                      <WaBtn href={waFor('fee', m)} label="Remind" />
                      <Btn size="sm" onClick={() => setPayFor(m)}>Collect</Btn>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Card>
      )}

      {tab === 'history' && (
        <Card className="px-4">
          {history.length === 0 ? (
            <Empty text="No payments found" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {history.slice(0, 200).map((p) => {
                const m = memberById[p.member_id]
                return (
                  <div key={p.id} className="flex flex-wrap items-center gap-3 py-3 text-sm">
                    <div className="min-w-0 flex-1 basis-40">
                      {m ? (
                        <Link to={`/members/${m.id}`} className="block truncate font-medium hover:text-orange-400">{m.name}</Link>
                      ) : (
                        <span className="font-medium">Deleted member</span>
                      )}
                      <div className="text-xs text-neutral-400">
                        {fmtDate(p.paid_on)} · {receiptNo(p.receipt_no)}
                        {p.note ? ` · ${p.note}` : ''}
                      </div>
                    </div>
                    <Badge>{p.method.toUpperCase()}</Badge>
                    <span className="font-semibold text-green-400">{money(p.amount)}</span>
                    <Btn size="sm" variant="ghost" onClick={() => setReceipt(p)}>Receipt</Btn>
                  </div>
                )
              })}
              {history.length > 200 && (
                <div className="py-3 text-center text-xs text-neutral-500">Showing latest 200. Use filters or export CSV for more.</div>
              )}
            </div>
          )}
        </Card>
      )}

      {tab === 'revenue' && (
        <div className="grid gap-5 lg:grid-cols-2">
          <Card className="p-4">
            <h2 className="mb-2 font-semibold">Daily revenue – this month</h2>
            <RevenueChart data={daily} />
          </Card>
          <Card className="p-4">
            <h2 className="mb-2 font-semibold">Monthly revenue</h2>
            <RevenueChart data={lastMonths(6).map((x) => ({ label: x.label, revenue: monthly.find((r) => r.key === x.key)?.revenue || 0 }))} />
          </Card>
          <Card className="p-4 lg:col-span-2">
            <h2 className="mb-2 font-semibold">Last 12 months</h2>
            <div className="divide-y divide-neutral-800 text-sm">
              {monthly.map((r) => (
                <div key={r.key} className="flex justify-between py-2">
                  <span>{r.full}</span>
                  <span className="text-neutral-400">
                    {r.count} payment{r.count === 1 ? '' : 's'} · <b className="text-white">{money(r.revenue)}</b>
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {payFor && <PaymentModal member={payFor} onClose={() => setPayFor(null)} onDone={setReceipt} />}
      {receipt && <Receipt payment={receipt} onClose={() => setReceipt(null)} />}
    </>
  )
}
