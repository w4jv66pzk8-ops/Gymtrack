import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { AlertTriangle, CalendarCheck, Clock, Plus, UserCheck, UserX, Users, Wallet } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Btn, Card, Empty, MemBadge, MemberLine, PageHeader, StatCard, WaBtn } from '../components/UI'
import RevenueChart from '../components/RevenueChart'
import MemberForm from '../components/MemberForm'
import PaymentModal from '../components/PaymentModal'
import RenewModal from '../components/RenewModal'
import Receipt from '../components/Receipt'
import { fmtDate, lastMonths, sumAmount, today } from '../lib/utils'

export default function Dashboard() {
  const { members, payments, attendance, settings, money, waFor } = useData()
  const [adding, setAdding] = useState(false)
  const [payFor, setPayFor] = useState(null)
  const [renewFor, setRenewFor] = useState(null)
  const [receipt, setReceipt] = useState(null)

  const d = useMemo(() => {
    const t = today()
    const live = members.filter((m) => m.status === 'active')
    const expiring = live.filter((m) => m.mstate === 'expiring').sort((a, b) => a.daysLeft - b.daysLeft)
    const expired = live.filter((m) => m.mstate === 'expired').sort((a, b) => b.daysLeft - a.daysLeft)
    const owing = members.filter((m) => m.due > 0).sort((a, b) => b.due - a.due)
    const missing = live.filter((m) => m.absent >= 7).sort((a, b) => b.absent - a.absent)
    const markedInactive = members.filter((m) => m.status === 'inactive').length
    return {
      total: members.length,
      active: live.filter((m) => m.mstate !== 'expired').length,
      todayTotal: sumAmount(payments.filter((p) => p.paid_on === t)),
      monthTotal: sumAmount(payments.filter((p) => p.paid_on.startsWith(t.slice(0, 7)))),
      pending: owing.reduce((s, m) => s + m.due, 0),
      owing,
      expiring,
      expired,
      missing,
      markedInactive,
      checkins: attendance.filter((a) => a.visit_date === t).length,
      chart: lastMonths(6).map((x) => ({
        label: x.label,
        revenue: sumAmount(payments.filter((p) => p.paid_on.startsWith(x.key))),
      })),
    }
  }, [members, payments, attendance])

  const reminders = [...d.expiring, ...d.expired].slice(0, 6)

  return (
    <>
      <PageHeader title="Dashboard" sub={`${settings.gym_name} · ${fmtDate(today())}`}>
        <Link to="/attendance">
          <Btn variant="outline"><CalendarCheck size={16} /> Attendance</Btn>
        </Link>
        <Btn onClick={() => setAdding(true)}><Plus size={16} /> Add member</Btn>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <StatCard icon={Users} label="Total members" value={d.total} sub={`${d.markedInactive} marked inactive`} to="/members" />
        <StatCard icon={UserCheck} label="Active members" value={d.active} sub={`${d.checkins} checked in today`} to="/attendance" />
        <StatCard icon={Wallet} label="Today's collections" value={money(d.todayTotal)} sub={`${money(d.monthTotal)} this month`} to="/fees" accent />
        <StatCard icon={AlertTriangle} label="Pending fees" value={money(d.pending)} sub={`${d.owing.length} members owe`} to="/fees" />
        <StatCard icon={Clock} label="Expiring soon" value={d.expiring.length} sub={`within ${settings.expiry_alert_days} days · ${d.expired.length} expired`} to="/renewals" />
        <StatCard icon={UserX} label="Inactive members" value={d.missing.length + d.markedInactive} sub={`${d.missing.length} absent 7+ days`} to="/missing" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Card className="p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-semibold">Renewal reminders</h2>
            <Link to="/renewals" className="text-xs text-orange-400 hover:underline">View all</Link>
          </div>
          {reminders.length === 0 ? (
            <Empty text="No memberships expiring soon 🎉" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {reminders.map((m) => (
                <MemberLine
                  key={m.id}
                  m={m}
                  sub={`${m.plan_name} · ends ${fmtDate(m.expiry_date)}`}
                  actions={
                    <>
                      <MemBadge m={m} />
                      <WaBtn href={waFor('renewal', m)} />
                      <Btn size="sm" onClick={() => setRenewFor(m)}>Renew</Btn>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Card>

        <Card className="p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-semibold">Monthly revenue</h2>
            <span className="text-xs text-neutral-500">Last 6 months</span>
          </div>
          <RevenueChart data={d.chart} />
        </Card>

        <Card className="p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-semibold">Pending fees</h2>
            <Link to="/fees" className="text-xs text-orange-400 hover:underline">View all</Link>
          </div>
          {d.owing.length === 0 ? (
            <Empty text="Everyone is paid up 🎉" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {d.owing.slice(0, 5).map((m) => (
                <MemberLine
                  key={m.id}
                  m={m}
                  sub={`${m.plan_name} · paid ${money(m.cycle_paid)} of ${money(m.cycle_fee)}`}
                  actions={
                    <>
                      <span className="text-sm font-semibold text-orange-400">{money(m.due)}</span>
                      <WaBtn href={waFor('fee', m)} label="Remind" />
                      <Btn size="sm" onClick={() => setPayFor(m)}>Collect</Btn>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Card>

        <Card className="p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-semibold">Missing members</h2>
            <Link to="/missing" className="text-xs text-orange-400 hover:underline">View all</Link>
          </div>
          {d.missing.length === 0 ? (
            <Empty text="Nobody has been absent for 7+ days 💪" />
          ) : (
            <div className="divide-y divide-neutral-800">
              {d.missing.slice(0, 5).map((m) => (
                <MemberLine
                  key={m.id}
                  m={m}
                  sub={`Last visit ${m.last_visit ? fmtDate(m.last_visit) : 'never'}`}
                  actions={
                    <>
                      <span className="text-sm font-semibold text-red-400">{m.absent} days</span>
                      <WaBtn href={waFor('followup', m)} label="Follow up" />
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Card>
      </div>

      {adding && <MemberForm onClose={() => setAdding(false)} onSaved={(res) => res?.payment && setReceipt(res.payment)} />}
      {payFor && <PaymentModal member={payFor} onClose={() => setPayFor(null)} onDone={setReceipt} />}
      {renewFor && <RenewModal member={renewFor} onClose={() => setRenewFor(null)} onDone={(p) => p && setReceipt(p)} />}
      {receipt && <Receipt payment={receipt} onClose={() => setReceipt(null)} />}
    </>
  )
}
