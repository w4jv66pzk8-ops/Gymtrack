import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Download, Plus, Search } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Avatar, Badge, Btn, Card, Empty, MemBadge, PageHeader, PayBadge, WaBtn, inputCls } from '../components/UI'
import MemberForm from '../components/MemberForm'
import PaymentModal from '../components/PaymentModal'
import Receipt from '../components/Receipt'
import { download, fmtDate, membersCSV, today } from '../lib/utils'

const FILTERS = [
  { id: 'all', label: 'All', test: () => true },
  { id: 'active', label: 'Active', test: (m) => m.status === 'active' },
  { id: 'inactive', label: 'Inactive', test: (m) => m.status === 'inactive' },
  { id: 'paid', label: 'Paid', test: (m) => m.pay === 'paid' },
  { id: 'partial', label: 'Partially paid', test: (m) => m.pay === 'partial' },
  { id: 'unpaid', label: 'Unpaid', test: (m) => m.pay === 'unpaid' },
  { id: 'expiring', label: 'Expiring soon', test: (m) => m.mstate === 'expiring' },
  { id: 'expired', label: 'Expired', test: (m) => m.mstate === 'expired' },
]

export default function Members() {
  const { members, money, waFor } = useData()
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('all')
  const [adding, setAdding] = useState(false)
  const [payFor, setPayFor] = useState(null)
  const [receipt, setReceipt] = useState(null)

  const list = useMemo(() => {
    const test = FILTERS.find((f) => f.id === filter).test
    const s = q.trim().toLowerCase()
    return members.filter((m) => test(m) && (!s || m.name.toLowerCase().includes(s) || m.phone.includes(s)))
  }, [members, q, filter])

  return (
    <>
      <PageHeader title="Members" sub={`${members.length} total · ${list.length} shown`}>
        <Btn variant="outline" onClick={() => download(`gymtrack-members-${today()}.csv`, membersCSV(list))}>
          <Download size={16} /> Export CSV
        </Btn>
        <Btn onClick={() => setAdding(true)}><Plus size={16} /> Add member</Btn>
      </PageHeader>

      <div className="relative mb-3">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
        <input className={`${inputCls} pl-9`} placeholder="Search by name or phone…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className={`whitespace-nowrap rounded-full border px-3.5 py-1.5 text-xs font-medium transition ${
              filter === f.id
                ? 'border-orange-500 bg-orange-500 text-white'
                : 'border-neutral-800 text-neutral-400 hover:border-neutral-600'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <Card>
        {list.length === 0 ? (
          <Empty text={members.length === 0 ? 'No members yet. Add your first member.' : 'No members match your search.'} />
        ) : (
          <div className="divide-y divide-neutral-800">
            {list.map((m) => (
              <div key={m.id} className="flex flex-wrap items-center gap-3 p-4">
                <Avatar name={m.name} />
                <div className="min-w-0 flex-1 basis-48">
                  <Link to={`/members/${m.id}`} className="block truncate font-medium hover:text-orange-400">
                    {m.name}
                  </Link>
                  <div className="text-xs text-neutral-400">
                    {m.phone} · {m.plan_name} · till {fmtDate(m.expiry_date)}
                  </div>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    <PayBadge status={m.pay} />
                    <MemBadge m={m} />
                    {m.due > 0 && <Badge tone="orange">Due {money(m.due)}</Badge>}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {m.due > 0 && <Btn size="sm" onClick={() => setPayFor(m)}>Collect</Btn>}
                  <WaBtn href={waFor(m.due > 0 ? 'fee' : m.mstate === 'active' ? 'followup' : 'renewal', m)} />
                  <Link to={`/members/${m.id}`}>
                    <Btn size="sm" variant="ghost">View</Btn>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {adding && <MemberForm onClose={() => setAdding(false)} onSaved={(res) => res?.payment && setReceipt(res.payment)} />}
      {payFor && <PaymentModal member={payFor} onClose={() => setPayFor(null)} onDone={setReceipt} />}
      {receipt && <Receipt payment={receipt} onClose={() => setReceipt(null)} />}
    </>
  )
}
