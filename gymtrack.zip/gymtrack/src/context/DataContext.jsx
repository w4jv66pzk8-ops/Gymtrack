import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './AuthContext'
import * as U from '../lib/utils'

const Ctx = createContext(null)
export const useData = () => useContext(Ctx)

const EMPTY = { plans: [], members: [], payments: [], attendance: [], renewals: [], settings: null }
const TABLES = ['plans', 'members', 'payments', 'attendance', 'renewals', 'settings']

const must = (res) => {
  if (res.error) throw new Error(res.error.message)
  return res.data
}

// Supabase returns max 1000 rows per request, so page through bigger tables.
async function fetchAll(table, build = (q) => q) {
  let all = []
  let from = 0
  for (;;) {
    const rows = must(await build(supabase.from(table).select('*')).range(from, from + 999))
    all = all.concat(rows)
    if (rows.length < 1000) return all
    from += 1000
  }
}

export function DataProvider({ children }) {
  const { session } = useAuth()
  const [raw, setRaw] = useState(EMPTY)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = useCallback(async () => {
    try {
      const since = U.addDays(U.today(), -120)
      const [plans, members, payments, attendance, renewals, settings] = await Promise.all([
        fetchAll('plans', (q) => q.order('months').order('name')),
        fetchAll('members', (q) => q.order('name')),
        fetchAll('payments', (q) =>
          q.order('paid_on', { ascending: false }).order('receipt_no', { ascending: false })
        ),
        fetchAll('attendance', (q) => q.gte('visit_date', since).order('visit_date', { ascending: false })),
        fetchAll('renewals', (q) => q.order('renewed_on', { ascending: false })),
        supabase.from('settings').select('*').eq('id', 1).maybeSingle().then(must),
      ])
      setRaw({ plans, members, payments, attendance, renewals, settings })
      setError(null)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (session) load()
  }, [session, load])

  const settings = useMemo(() => ({ ...U.DEFAULT_SETTINGS, ...(raw.settings || {}) }), [raw.settings])
  const money = useCallback((n) => U.money(n, settings.currency), [settings.currency])

  // Members with derived fields: pay status, dues, membership state, absence
  const members = useMemo(
    () =>
      raw.members.map((m) => ({
        ...m,
        pay: U.paymentStatus(m),
        due: Math.max(0, Number(m.cycle_fee) - Number(m.cycle_paid)),
        mstate: U.membershipState(m, settings.expiry_alert_days),
        daysLeft: U.daysUntil(m.expiry_date),
        absent: U.daysAbsent(m),
      })),
    [raw.members, settings.expiry_alert_days]
  )
  const memberById = useMemo(() => Object.fromEntries(members.map((m) => [m.id, m])), [members])

  // WhatsApp link for 'renewal' | 'followup' | 'fee' messages
  const waFor = useCallback(
    (kind, m) => {
      const days =
        kind === 'renewal'
          ? m.daysLeft < 0
            ? `expired ${-m.daysLeft} days ago`
            : m.daysLeft === 0
            ? 'today'
            : `in ${m.daysLeft} days`
          : String(m.absent)
      const text = U.fill(settings[`${kind}_template`], {
        name: m.name,
        gym: settings.gym_name,
        expiry: U.fmtDate(m.expiry_date),
        days,
        amount: U.money(m.due, settings.currency),
      })
      return U.waLink(m.phone, text, settings.country_code)
    },
    [settings]
  )

  // Run a write, then refresh everything
  const act = useCallback(
    async (fn) => {
      const result = await fn()
      await load()
      return result
    },
    [load]
  )

  // ---------- Members ----------
  const addMember = (f) =>
    act(async () => {
      const plan = raw.plans.find((p) => p.id === f.plan_id)
      if (!plan) throw new Error('Please choose a plan')
      const paid = Number(f.paid_amount || 0)
      const member = must(
        await supabase
          .from('members')
          .insert({
            name: f.name.trim(),
            phone: f.phone,
            joining_date: f.joining_date,
            plan_id: plan.id,
            plan_name: plan.name,
            plan_months: plan.months,
            cycle_start: f.joining_date,
            expiry_date: U.addMonths(f.joining_date, plan.months),
            cycle_fee: Number(f.fee_amount),
            cycle_paid: paid,
            notes: f.notes?.trim() || null,
          })
          .select()
          .single()
      )
      let payment = null
      if (paid > 0) {
        payment = must(
          await supabase
            .from('payments')
            .insert({
              member_id: member.id,
              amount: paid,
              paid_on: f.joining_date,
              method: f.method,
              note: 'Joining payment',
            })
            .select()
            .single()
        )
      }
      return { member, payment }
    })

  const updateMember = (id, patch) =>
    act(async () => must(await supabase.from('members').update(patch).eq('id', id)))

  const deleteMember = (id) =>
    act(async () => must(await supabase.from('members').delete().eq('id', id)))

  const setStatus = (id, status) => updateMember(id, { status })

  // ---------- Payments ----------
  const addPayment = (member, { amount, method, paid_on, note }) =>
    act(async () => {
      const amt = Number(amount)
      const payment = must(
        await supabase
          .from('payments')
          .insert({ member_id: member.id, amount: amt, paid_on, method, note: note?.trim() || null })
          .select()
          .single()
      )
      must(
        await supabase
          .from('members')
          .update({ cycle_paid: Number(member.cycle_paid) + amt })
          .eq('id', member.id)
      )
      return payment
    })

  // ---------- Renewals & plan changes ----------
  const renewMember = (member, f) =>
    act(async () => {
      const plan = raw.plans.find((p) => p.id === f.plan_id)
      if (!plan) throw new Error('Please choose a plan')
      const expired = U.daysUntil(member.expiry_date) < 0
      const start = expired ? U.today() : member.expiry_date
      const newExpiry = U.addMonths(start, plan.months)
      const carry = Math.max(0, Number(member.cycle_fee) - Number(member.cycle_paid))
      const paid = Number(f.paid_amount || 0)

      must(
        await supabase.from('renewals').insert({
          member_id: member.id,
          plan_name: plan.name,
          months: plan.months,
          amount: Number(f.fee_amount),
          old_expiry: member.expiry_date,
          new_expiry: newExpiry,
          renewed_on: U.today(),
        })
      )
      must(
        await supabase
          .from('members')
          .update({
            plan_id: plan.id,
            plan_name: plan.name,
            plan_months: plan.months,
            cycle_start: start,
            expiry_date: newExpiry,
            cycle_fee: Number(f.fee_amount) + carry,
            cycle_paid: paid,
            status: 'active',
          })
          .eq('id', member.id)
      )
      let payment = null
      if (paid > 0) {
        payment = must(
          await supabase
            .from('payments')
            .insert({
              member_id: member.id,
              amount: paid,
              paid_on: U.today(),
              method: f.method,
              note: `Renewal - ${plan.name}`,
            })
            .select()
            .single()
        )
      }
      return payment
    })

  const changePlan = (member, planId, fee) =>
    act(async () => {
      const plan = raw.plans.find((p) => p.id === planId)
      if (!plan) throw new Error('Please choose a plan')
      must(
        await supabase
          .from('members')
          .update({
            plan_id: plan.id,
            plan_name: plan.name,
            plan_months: plan.months,
            expiry_date: U.addMonths(member.cycle_start, plan.months),
            cycle_fee: Number(fee),
          })
          .eq('id', member.id)
      )
    })

  // ---------- Attendance ----------
  const markAttendance = (member, date) =>
    act(async () => {
      const { error: err } = await supabase
        .from('attendance')
        .insert({ member_id: member.id, visit_date: date })
      if (err) throw new Error(err.code === '23505' ? 'Already marked present for this day' : err.message)
      const patch = { status: 'active' }
      if (!member.last_visit || date > member.last_visit) patch.last_visit = date
      must(await supabase.from('members').update(patch).eq('id', member.id))
    })

  const unmarkAttendance = (member, date) =>
    act(async () => {
      must(await supabase.from('attendance').delete().eq('member_id', member.id).eq('visit_date', date))
      const rows = must(
        await supabase
          .from('attendance')
          .select('visit_date')
          .eq('member_id', member.id)
          .order('visit_date', { ascending: false })
          .limit(1)
      )
      must(
        await supabase
          .from('members')
          .update({ last_visit: rows[0]?.visit_date || null })
          .eq('id', member.id)
      )
    })

  // ---------- Plans ----------
  const addPlan = (f) =>
    act(async () =>
      must(
        await supabase
          .from('plans')
          .insert({ name: f.name.trim(), months: Number(f.months), price: Number(f.price) })
      )
    )
  const updatePlan = (id, f) =>
    act(async () =>
      must(
        await supabase
          .from('plans')
          .update({ name: f.name.trim(), months: Number(f.months), price: Number(f.price) })
          .eq('id', id)
      )
    )
  const deletePlan = (id) => act(async () => must(await supabase.from('plans').delete().eq('id', id)))

  // ---------- Settings ----------
  const saveSettings = (patch) =>
    act(async () => must(await supabase.from('settings').upsert({ id: 1, ...patch })))

  // ---------- Backup / restore ----------
  const backup = async () => {
    const out = { app: 'GYMTRACK', version: 1, exported_at: new Date().toISOString() }
    for (const t of TABLES) out[t] = await fetchAll(t)
    return out
  }
  const restore = (data) =>
    act(async () => {
      if (data?.app !== 'GYMTRACK') throw new Error('This is not a GYMTRACK backup file')
      for (const t of TABLES) {
        const rows = data[t] || []
        for (let i = 0; i < rows.length; i += 500) {
          must(await supabase.from(t).upsert(rows.slice(i, i + 500)))
        }
      }
      await supabase.rpc('fix_receipt_seq')
    })

  const value = {
    loading,
    error,
    reload: load,
    settings,
    plans: raw.plans,
    members,
    memberById,
    payments: raw.payments,
    attendance: raw.attendance,
    renewals: raw.renewals,
    money,
    waFor,
    addMember,
    updateMember,
    deleteMember,
    setStatus,
    addPayment,
    renewMember,
    changePlan,
    markAttendance,
    unmarkAttendance,
    addPlan,
    updatePlan,
    deletePlan,
    saveSettings,
    backup,
    restore,
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
